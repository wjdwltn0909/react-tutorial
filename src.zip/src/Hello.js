import React from "react";
import BorderBox from "./BorderBox";

function Hello() {
    return (
        <BorderBox>
            <div>
                <h1>안녕하세요</h1>
                <h2>네이버 클라우드 13기 첫번째 리액트 컴포넌트입니다.</h2>
            </div>
            <div>
                <h2>두번째 디브입니다.</h2>
            </div>
        </BorderBox>

    );
}

export default Hello;

